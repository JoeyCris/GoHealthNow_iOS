//
//  ServingSizeUnitViewController.h
//  GlucoGuide
//
//  Created by Haoyu Gu on 2015-05-27.
//  Copyright (c) 2015 GlucoGuide. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ServingSizeUnitViewController : UIView

@property (nonatomic) float value;

@end
