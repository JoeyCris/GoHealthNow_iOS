//
//  ViewController.h
//  testSignUpScreens
//
//  Created by John Wreford on 2015-08-29.
//  Copyright (c) 2015 John Wreford. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterLoginViewController : UIViewController 


@end

