//
//  InputViewController.h
//  GlucoGuide
//
//  Created by Siddarth Kalra on 2015-04-30.
//  Copyright (c) 2015 GlucoGuide. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreMotion/CoreMotion.h>

@interface InputViewController : UITableViewController

@property (strong, nonatomic) CMPedometer *pedometer;



@end
