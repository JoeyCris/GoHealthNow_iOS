//
//  AddA1CViewController.h
//  GlucoGuide
//
//  Created by QuQi on 2016-08-19.
//  Copyright © 2016 GlucoGuide. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddA1CViewController : UITableViewController

@end
