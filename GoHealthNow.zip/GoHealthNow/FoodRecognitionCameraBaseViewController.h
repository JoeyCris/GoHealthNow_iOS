//
//  FoodRecognitionCameraBaseViewController.h
//  GlucoGuide
//
//  Created by Haoyu Gu on 2016-05-03.
//  Copyright © 2016 GlucoGuide. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FoodRecognitionCameraBaseViewController : UIViewController

@end
