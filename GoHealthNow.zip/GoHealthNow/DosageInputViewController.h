//
//  ViewController.h
//  reminders
//
//  Created by John Wreford on 2015-09-07.
//  Copyright (c) 2015 John Wreford. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DosageInputViewController: UIViewController <UITextViewDelegate>

@property (nonatomic) UILocalNotification *notification;



@end

