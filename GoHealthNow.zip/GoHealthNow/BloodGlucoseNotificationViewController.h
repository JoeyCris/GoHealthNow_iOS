//
//  ViewController.h
//  reminders
//
//  Created by John Wreford on 2015-10-10.
//  Copyright (c) 2015 John Wreford. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface BloodGlucoseNotificationViewController: UIViewController

@end

