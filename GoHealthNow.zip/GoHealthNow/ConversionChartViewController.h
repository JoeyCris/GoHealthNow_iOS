//
//  ViewController.h
//  singleton
//
//  Created by John Wreford on 2016-02-16.
//  Copyright © 2016 John Wreford. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ConversionChartViewController : UIViewController


@end

