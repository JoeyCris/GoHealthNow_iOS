//
//  ViewController.h
//  reminders
//
//  Created by John Wreford on 2015-10-26.
//  Copyright (c) 2015 John Wreford. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface BloodPressureNotificationViewController: UIViewController

@end

