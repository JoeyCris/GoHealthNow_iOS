//
//  MealPhotoViewController.h
//  GlucoGuide
//
//  Created by Haoyu Gu on 2016-05-15.
//  Copyright © 2016 GlucoGuide. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MealPhotoViewController : UIViewController

- (void)loadImage:(UIImage *)image;

@end
