//
//  GGPlotTheme.h
//  plotDemo
//
//  Created by HoriKu on 2015-04-28.
//  Copyright (c) 2015 HoriKu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CorePlot-CocoaTouch.h"

@interface GGPlotTheme : CPTTheme

@end
