//
//  LabTestTableViewController.h
//  GoHealthNow
//
//  Created by Haoyu Gu on 2017-05-25.
//  Copyright © 2017 GoHealthNow. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LabTestTableViewController : UITableViewController

@end
