//
//  ExerciseHistoryTableViewController.h
//  GlucoGuide
//
//  Created by Haoyu Gu on 2016-03-04.
//  Copyright © 2016 GlucoGuide. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ExerciseHistoryTableViewController : UITableViewController{
    
    NSString *passedStartDate;
    
}

@property (nonatomic) NSString *passedStartDate;

@end
