//
//  ShowPhotoController.h
//  GlucoGuide
//
//  Created by QuQi on 2016-05-12.
//  Copyright © 2016 GlucoGuide. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShowPhotoController : UIViewController
@property (nonatomic, strong) UIImage *imageToShow;
@end
