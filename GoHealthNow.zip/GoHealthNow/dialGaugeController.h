//
//  dialGaugeController.h
//  GlucoGuide
//
//  Created by QuQi on 2016-06-10.
//  Copyright © 2016 GlucoGuide. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface dialGaugeController : UITableViewController

@end
