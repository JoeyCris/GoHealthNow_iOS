//
//  UIAlertController+Window.h
//  FFM
//
// 
//

#import <UIKit/UIKit.h>

@interface UIAlertController (Window)

- (void)show;
- (void)show:(BOOL)animated;

@end
